This code corresponds to the method that is used for peak detection in "The spatio temporal program of DNA replication is driven by specific epigenetic signatures in human cells", Picard et al. (2013)

Compilation :
g++  -Wall -c -g main_scanquantile.cc;g++ -c -g scanstat.cc;  g++ -g main_scanquantile.o scanstat.o -o scanquantile

syntax : ./scanquantile u alpha startregion endregion filein.txt

u           : size of window 
alpha       : level of detection 
startregion : starting coordinate to run the scan on a given region
endregion   : ending coordinate
filein      : 2-column file containing positions of reads (1st column) and the number of reads (2nd column)

Exemple : ./scanquantile 2000 0.0001 2699571 3678660 fake.txt

2711739	2711770	2711769	38.9897	39
2746001	2749790	2747984	38.9897	188
2843483	2851679	2847141	38.9897	619
2931636	2932897	2932612	38.9897	53
2984258	2984514	2984511	38.9897	40
3205703	3207540	3206386	38.9897	61
3392999	3393149	3393148	38.9897	39
3464384	3466098	3464872	38.9897	55
3557273	3559273	3558597	38.9897	70
3609414	3611877	3610734	38.9897	79
3629076	3629078	3629077	38.9897	40
3629112	3629114	3629113	38.9897	39
3629137	3633545	3632263	38.9897	89

output : 
col 1 : peak start
col 2 : peak position
col 3 : peak end
col 4 : level of thresholding (quantile)
col 5 : height of the peak

/* Author F. Picard franck.picard@univ-lyon1.fr */

