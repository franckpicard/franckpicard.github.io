#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class scanstat
{
  public:
  int      _NbOcc;     // Number of occurences
  int      _lengthS;   // length of the sequence
  int      _u;         // length of the scan
  int   _Mnu;
  double   _sumW;
  double   _log1mPval;
  vector<double> _Scan;       // scan vector
  vector<double> _WScan;       // scan vector
  scanstat(int nbocc, int lengthseq, int w);
  void computeScans(vector<int> Position, vector<double> Weights);
  void computeQuantile(double x);
  ~scanstat();
};
/* Author F. Picard franck.picard@univ-lyon1.fr */
